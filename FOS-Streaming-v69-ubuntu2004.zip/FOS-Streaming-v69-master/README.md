# FOS-Streaming-v69
## Features:
- Streaming and restreaming (authentication, m3u8)
- Manage users (overview, add, edit, delete, enable, disable)
- Manage categories (overview, add, edit, delete)
- Manage streams (overview, add, edit, delete,start,stop)
- Manage settings (configuration)
- Autorestart (cron.php need to set manual)
- Transcode
- Last IP connected
- h264_mp4toannexb
- play stream
- Playlist import
- Multiple streams on one channel
- Limit streams on users
- IP Block
- User Agent block
- predefined transcode profiles


## Installation (Ubuntu 20.04)
1. **`SUPPORTED DISTRO : Ubuntu 20.04`** (PHP 7.4-FPM, nginx, MariaDB 10.3, ffmpeg 4.2 from the Ubuntu repositories)
2. Upload/extract this project on the server and, as root, run: `bash install/ubuntu2004`
3. **`Visit : http://your-ip:7777/ login with User : admin Password : admin`**
4. **`Change "Web ip: *" with your public IPv4 server ip at http://your-ip:7777/settings.php`**
5. Auto-restart cron is installed by the script (`/etc/cron.d/fos-streaming`, every 2 minutes, runs as user `nginx`)
6. **`Mysql Password : cat /root/FOS_MYSQL_PASSWORD`**
7. Open TCP ports 7777 (panel) and 8000 (streams) in your firewall.

Services: `systemctl status fos-nginx php7.4-fpm mariadb`

(The old Debian 11 installer is still available in `install/debian11`.)

### Change port of panel
1. change port in webinterface -> Settings -> web Port
2. (the panel rewrites /home/fos-streaming/fos/nginx/conf/nginx.conf for you)
3. `systemctl restart fos-nginx`

## How can I use it?
- Default login: admin / admin
  - Add user
  - Add stream and use defined transcode profile 1 called **Default 1**
- You can use it also in proxy mode, but that depends on how you want to use it.
- The most stable way is using transcode profile: **Default 1** without proxy mode ticket

## Sources
1. FOS-Streaming-v1
2. ffmpeg
3. nginx, nginx-rtmp-module, nginx-geoip2-module
