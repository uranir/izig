#!/bin/bash
# Rebuilds the "www1" copy used by the streaming port (8000) from "www" and restarts the services.
# Ubuntu 20.04 / systemd version.
#   bash fosportsupdate.sh               -> rebuild www1 and restart fos-nginx + php-fpm
#   bash fosportsupdate.sh --build-only  -> only rebuild www1 (used by install/ubuntu2004)

BASE=/home/fos-streaming/fos
WWW=$BASE/www
WWW1=$BASE/www1
PHPV=7.4

if [ "$1" != "--build-only" ]; then
    systemctl stop fos-nginx
    systemctl stop php$PHPV-fpm
fi

mkdir -p $WWW1/log
rm -rf $WWW1/*.* $WWW1/hl
cp -R $WWW/* $WWW1/
rm -f $WWW1/*.*
rm -rf $WWW1/hl
ln -sfn $WWW/hl            $WWW1/hl
ln -sf  $WWW/config.php    $WWW1/config.php
ln -sf  $WWW/functions.php $WWW1/functions.php
ln -sf  $WWW/stream.php    $WWW1/stream.php
ln -sf  $WWW/playlist.php  $WWW1/playlist.php
chown -R nginx:nginx $WWW1/log

if [ "$1" != "--build-only" ]; then
    systemctl start php$PHPV-fpm
    systemctl start fos-nginx
fi
